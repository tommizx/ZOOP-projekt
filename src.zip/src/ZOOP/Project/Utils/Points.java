package ZOOP.Project.Utils;

import ZOOP.Project.Model.*;
import ZOOP.Project.Model.Math;

public class Points {
    public static void resetPoints(ActiveUser activeUser){
        activeUser.setActiveUserPoints(0);
    }
    public static void setHighestScore(ActiveUser activeUser, Category currentCategory){
        currentCategory.setActiveHighestScore(activeUser.getActiveUserPoints());
    }
}
