package ZOOP.Project;

import ZOOP.Project.Model.*;
import ZOOP.Project.Model.Math;
import ZOOP.Project.Stages.Game;
import ZOOP.Project.Utils.Points;
import ZOOP.Project.Utils.Question;
import ZOOP.Project.Model.Geography;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Game game = new Game();
        do {
            if (game.gameStageString.equals("start") || game.gameStageString.equals("logout")) {
                game.userLoginStage();
            }
            if (game.gameStageString.equals("start") || game.gameStageString.equals("logout") || game.gameStageString.equals("selection")) {
                game.categorySelectionStage();
            }
            game.gameStage();
        }while(!(game.gameStageString.equals("exit")));
    }
}